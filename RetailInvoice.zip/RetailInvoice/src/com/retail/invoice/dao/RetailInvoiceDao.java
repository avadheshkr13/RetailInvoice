package com.retail.invoice.dao;

import java.util.List;

import com.retail.invoice.entity.Product;

public interface RetailInvoiceDao {
	/*public String insertNewBookInfo(Book addBook);
    public Book getBookInfo(int bookId);
    public String updateBookInfo(Book updateBook);
    public String removeBookInfo(Book removeBook);
    public List<Book> getAllBookInfo();*/
	
	public List<Product> getProductById(List<Integer> productIdList);
}
