package com.retail.invoice.dao;

import java.util.List;

import javax.persistence.Query;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.retail.invoice.entity.Product;

@Repository("retailInvoiceDao")
public class RetailInvoiceDaoImpl implements RetailInvoiceDao {

	@Autowired
	private SessionFactory sessionFactory;

	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}
	public SessionFactory setSessionFactory(SessionFactory sessionFactory) {
		return this.sessionFactory=sessionFactory;
	}

	@Override
	@Transactional
	public List<Product> getProductById(List<Integer> productIdList) {
		// retrieve book object based on the id supplied in the formal argument
		Query query = sessionFactory.getCurrentSession().createQuery("from  " + Product.class.getName() + " where productId in (:productIdList)  ");
	    query.setParameter("productIdList", productIdList);
	    return (List<Product>) query.getResultList();
	}

}
