package com.retail.invoice.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.retail.invoice.dao.RetailInvoiceDao;
import com.retail.invoice.entity.Product;
import com.retail.invoice.model.Invoice;
import com.retail.invoice.model.ProductMap;

@Component
public class RetailInvoiceServiceImpl implements RetailInvoiceService {

	@Autowired
	private RetailInvoiceDao retailInvoiceDao;

	@Override
	public Invoice generateInvoice(List<ProductMap> productMapList) {
		List<Integer> idList = new ArrayList<Integer>();
		HashMap<Integer, Integer> productHashMap = new HashMap<Integer, Integer>();
		for(ProductMap productMap: productMapList){
			idList.add(productMap.getId());
			productHashMap.put(productMap.getId(), productMap.getCount());
		}
		List<Product> productsList = retailInvoiceDao.getProductById(idList);
		return generateInvoice(productsList, productHashMap);
	}
	
	private Invoice generateInvoice(List<Product> productsList, HashMap<Integer, Integer> productHashMap){
		Invoice invoice = new Invoice();
		Map<String, Double> productPriceMap=new HashMap<String, Double>();
		double totalCost = 0.0;
		for (Product product: productsList) {
			int count = productHashMap.get(product.getProductId());
			double productPrice = (product.getProductPrice())*count*(1+product.getProductTax()/100);
			productPriceMap.put(product.getProductName(), productPrice);
			totalCost+=productPrice;
			
		}
		invoice.setProductPriceMap(productPriceMap);
		invoice.setTotalCost(totalCost);
		return invoice;
	}

}
