package com.retail.invoice.service;

import java.util.List;

import com.retail.invoice.model.Invoice;
import com.retail.invoice.model.ProductMap;

public interface RetailInvoiceService {
	public Invoice generateInvoice(List<ProductMap> productMap);
}
