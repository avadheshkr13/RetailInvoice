package com.retail.invoice.model;

import java.util.Map;

public class Invoice {
	private Map<String, Double> productPriceMap;
	private double totalCost;

	public Map<String, Double> getProductPriceMap() {
		return productPriceMap;
	}

	public void setProductPriceMap(Map<String, Double> productPriceMap) {
		this.productPriceMap = productPriceMap;
	}

	public double getTotalCost() {
		return totalCost;
	}

	public void setTotalCost(double totalCost) {
		this.totalCost = totalCost;
	}
}
