package com.retail.invoice.test;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.Invocation.Builder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.glassfish.jersey.client.ClientConfig;
public class TestInvoiceService {

	public static void main(String[] args) {
		// setting & invoking first service getBook/10001
        
        System.out.println("\n\nInvoking and executing Invoice service with request XML");
        String httpPostURL = "http://localhost:8080/RetailInvoice/rest/retailInvoice/invoice/";
        String requestString = "[{"
                +                   " \"id\": 1, "
                +                   " \"count\": 3"
                +               "},{"
                +                   " \"id\": 6, "
                +                   " \"count\": 4"
                +               "}]";
        String responseStringPost = testInvoiceServiceForPostRequest(httpPostURL, requestString);
        System.out.println("POST >> Response String : " + responseStringPost);

	}

	private static String testInvoiceServiceForPostRequest(String httpPostURL, String requestString) {

        // local variables
        ClientConfig clientConfig = null;
        Client client = null;
        WebTarget webTarget = null;
        Builder builder = null;
        Response response = null;
        int responseCode;
        String responseMessageFromServer = null;
        String responseString = null;
 
        try{
            // invoke service after setting necessary parameters
            clientConfig = new ClientConfig();
            client =  ClientBuilder.newClient(clientConfig);
            //          client.property("Content-Type", MediaType.APPLICATION_FORM_URLENCODED);
            //          client.property("accept", MediaType.APPLICATION_JSON);
            webTarget = client.target(httpPostURL);
 
            // invoke service
            builder = webTarget.request(MediaType.APPLICATION_FORM_URLENCODED).accept(MediaType.APPLICATION_JSON);
            response = builder.post(Entity.entity(requestString, MediaType.APPLICATION_JSON));
 
            // get response code
            responseCode = response.getStatus();
            System.out.println("Response code: " + responseCode);
 
            if (response.getStatus() != 200) {
                throw new RuntimeException("Failed with HTTP error code : " + responseCode);
            }
 
            // get response message
            responseMessageFromServer = response.getStatusInfo().getReasonPhrase();
            System.out.println("ResponseMessageFromServer: " + responseMessageFromServer);
 
            // get response string
            responseString = response.readEntity(String.class);
        }
        catch(Exception ex) {
            ex.printStackTrace();
        }
        finally{
            // release resources, if any
            response.close();
            client.close();
        }
        return responseString;
	}

}
